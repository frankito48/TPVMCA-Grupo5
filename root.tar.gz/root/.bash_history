history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
hostname
hostname
apt
vim
vim /etc/apt/sources.list
apt update
apt-cache search
apt-cache search debian
apt-cache search debian12
apt-cache search debian|less
lsb_release -a
hostname TPServer
hostname
apt upgrade
apt autoremove
vim /etc/apt/sources.list
apt update
apt full-upgrade
reboot
lsb_release -a
apt update
apt install openssh-server
apt install openssh-serve
apt install openssh-server
cd /etc/ssh
ls -l
cat sshd_config
vim sshd_config
netstat
netstat -natupl
ip a
cd ..
vim network/interfaces
ip a
systemctl restart networking.service 
ip a
systemctl restart networking.service 
ip a
reboot
exit
ip a
vim /etc/ssh/sshd_config
systemctl restart ssh.service 
ssh root@192.168.1.248
exit
hostname
exit
cd .ssh
cat authorized_keys 
cd ..
ls
cat Material_Adicional_TPVMCA.tar.gz 
ls
exit
cd /
ls -l
ls /media
ls
cd ..
cd root
ls
ls Material_Adicional_TPVMCA
cat Material_Adicional_TPVMCA/clave_privada.txt 
ls
ls -la  Material_Adicional_TPVMCA
vim /etc/ssh/sshd_config
ls -la /root
cat /root/.ssh/authorized_keys 
vim /etc/default/keyboard 
setupcon
reboot
cat /root/Material_Adicional_TPVMCA/clave_publica.pub >> /root/.ssh/authorized_keys 
cat /root/.ssh/authorized_keys 
apt update
apt autoremove
apt-search apache
apt-cache search apache
apt-cache search apache2 |less
apt-get install apache2
apt-get install php
systemctl status apache
systemctl status apache2
ls /var/www/html/
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
ls /var/www/html/
rm /var/www/html/index.html 
ls /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
ls /var/www/html/
systemctl restart apache2
systemctl status apache2
ip a
php -v
apache2ctl -M | grep php
cat /var/www/html/index.php 
apache2ctl -M | grep php
tail -20 /var/log/apache2/error.log 
cat /var/www/html/index.php 
cat /var/www/html/index.php |less
apt install php-mysqli
systemctl restart apache2
apt install mariadb-server
systemctl status mariadb
ls /root/Material_Adicional_TPVMCA
systemctl start mariadb
systemctl enable mariadb
mysql < /root/Material_Adicional_TPVMCA/db.sql 
ip route show
shutdown -h now
blkid /dev/sdc1
vim etc/fstab
ls /etc
ls /etc/fstab 
ls -l /etc
vim etc/fstab
cat /etc/fstab 
vim etc/fstab
lsblk
fdisk /dev/sdc
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc1 /www_dir/
mount /dev/sdc2 /backup_dir/
lsblk
blkid /dev/sdc1
ip a
nano /etc/fstab 
vim /etc/fstab 
vim /etc/fstab 
mount -a
vim /etc/fstab 
mount -a
cp /root/Material_Adicional_TPVMCA/index.php /www_dir/
cp /root/Material_Adicional_TPVMCA/logo.png /www_dir/
ls /www_dir/
ls -;
ls -l
ls / -l
chown -R www-data:www-data /www_dir/
chmod -R 755 /www_dir/
vim /etc/apache2/sites-available/000-default.conf 
systemctl restart apache2
ls -l /
vim /etc/apache2/apache2.conf 
cat /etc/apache2/apache2.conf 
cat /etc/apache2/apache2.conf |less
vim /etc/apache2/apache2.conf 
systemctl restart apache2
cat /proc/partitions > /opt/particion
cat /opt/particion 
shutdown -h now
blkid /dev/sdc2
cd /opt
ls -ltr
ls -la
mkdir -p /opt/scripts
ls -la
vim scripts/backup_full.sh
bash /opt/scripts/backup_full.sh 
bash /opt/scripts/backup_full.sh -help
vim scripts/backup_full.sh
bash /opt/scripts/backup_full.sh /var/log /backup_dir
ls
cd ..
ls
cd backup_dir/
ls -ltr
vim /opt/scripts/backup_full.sh
rm log_bkp_date.tar.gz 
bash /opt/scripts/backup_full.sh /var/log /backup_dir
ls
crontab -e
vim /etc/crontab 
crontab -l
crontab -e
vim /etc/crontab 
cd /
crontab -l
vim /etc/crontab 
cd backup_dir/
ls
cat log_bkp_20260605.tar.gz 
cd ..
reboot
ls /backup_dir/
exit
