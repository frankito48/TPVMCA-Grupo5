#!/bin/bash

#-help
if [ "$1" == "-help" ];then
    echo "Uso: $0 <origen> <destino>"
    echo "Ejemplo: $0 /var/log /backup_dir"
    echo " origen: directorio a backupear"
    echo " destino: directorio donde guardar el backup"
    exit 0
fi


#Validacion de argumentos
if [ $# -ne 2 ]; then
    echo "Error: Se requieren 2 argumentos. Use -help para mas informacion."
    exit 1
fi


ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename $ORIGEN)

#Validacion de Origen
if [ ! -d "$ORIGEN" ]; then
    echo "Error: El directorio origen '$ORIGEN' no existe."
    exit 1
fi

#Validacion de Destino
if [ ! -d "$DESTINO" ];then
    echo "Error: El directorio destino '$DESTINO' no existe."
    exit 1
fi

#Ejecucion del backup comprimido en tar.gz
tar czf "$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz" "$ORIGEN"

if [ $? -eq 0 ]; then
    echo "Backup exitoso: $DESTINO/${NOMBRE}_bkp${FECHA}.tar.gz"
else
    echo "Ocurrio un error al realizar el backup."
    exit 1
fi
